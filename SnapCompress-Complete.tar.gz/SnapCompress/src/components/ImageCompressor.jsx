import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { FileImage, Download, X, Loader2, Clock } from 'lucide-react'
import { compressImage, downloadFile } from '../lib/imageCompression'

const ImageCompressor = ({ 
  files, 
  setFiles, 
  removeFile, 
  compressedCount, 
  setCompressedCount,
  setShowUpgradeModal,
  hasDelayActive 
}) => {
  const [delayCountdowns, setDelayCountdowns] = useState({})

  const compressFile = async (fileData) => {
    const { id, file } = fileData
    
    setFiles(prev => prev.map(f => 
      f.id === id ? { ...f, isCompressing: true, progress: 0 } : f
    ))

    try {
      const compressedFile = await compressImage(file, (progress) => {
        setFiles(prev => prev.map(f => 
          f.id === id ? { ...f, progress: Math.round(progress) } : f
        ))
      })

      setFiles(prev => prev.map(f => 
        f.id === id ? { 
          ...f, 
          compressed: compressedFile, 
          isCompressing: false, 
          isCompressed: true,
          progress: 100 
        } : f
      ))

      // Increment compressed count
      const newCount = compressedCount + 1
      setCompressedCount(newCount)

      // Show upgrade modal after 5 compressions
      if (newCount === 5) {
        setShowUpgradeModal(true)
      }

    } catch (error) {
      console.error('Compression failed:', error)
      setFiles(prev => prev.map(f => 
        f.id === id ? { ...f, isCompressing: false, progress: 0 } : f
      ))
    }
  }

  const compressAll = () => {
    files.forEach(fileData => {
      if (!fileData.isCompressed && !fileData.isCompressing) {
        compressFile(fileData)
      }
    })
  }

  const handleDownload = (fileData) => {
    const { compressed, file, id } = fileData
    
    if (!compressed) return

    // Check if we need to apply delay for free users
    if (compressedCount >= 5 && hasDelayActive) {
      // Start 20-second countdown
      setDelayCountdowns(prev => ({ ...prev, [id]: 20 }))
      
      const countdown = setInterval(() => {
        setDelayCountdowns(prev => {
          const newCount = prev[id] - 1
          if (newCount <= 0) {
            clearInterval(countdown)
            // Remove countdown and trigger download
            const { [id]: removed, ...rest } = prev
            downloadFile(compressed, `compressed_${file.name}`)
            return rest
          }
          return { ...prev, [id]: newCount }
        })
      }, 1000)
    } else {
      // Immediate download
      downloadFile(compressed, `compressed_${file.name}`)
    }
  }

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  return (
    <div className="space-y-4">
      {files.length > 0 && (
        <div className="flex gap-4 mb-4">
          <Button 
            onClick={compressAll}
            className="bg-white text-purple-600 hover:bg-gray-100"
            disabled={files.every(f => f.isCompressed || f.isCompressing)}
          >
            Compress All
          </Button>
        </div>
      )}

      {files.map((fileData) => {
        const { id, file, compressed, progress, isCompressing, isCompressed } = fileData
        const originalSize = formatFileSize(file.size)
        const compressedSize = compressed ? formatFileSize(compressed.size) : null
        const savings = compressed ? Math.round((1 - compressed.size / file.size) * 100) : 0
        const isInCountdown = delayCountdowns[id] > 0

        return (
          <div key={id} className="bg-white/5 rounded-lg p-4 border border-white/20">
            <div className="flex items-start gap-4">
              <FileImage className="text-white mt-1" size={20} />
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-white font-medium truncate">{file.name}</h4>
                  <button
                    onClick={() => removeFile(id)}
                    className="text-white/60 hover:text-white"
                  >
                    <X size={16} />
                  </button>
                </div>
                
                <div className="text-sm text-white/70 mb-2">
                  Original: {originalSize}
                  {compressedSize && (
                    <span className="ml-4">
                      Compressed: {compressedSize} ({savings}% smaller)
                    </span>
                  )}
                </div>

                {isCompressing && (
                  <div className="mb-3">
                    <div className="flex items-center gap-2 mb-1">
                      <Loader2 className="animate-spin text-white" size={16} />
                      <span className="text-sm text-white">Compressing... {progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                )}

                <div className="flex gap-2">
                  {!isCompressed && !isCompressing && (
                    <Button
                      onClick={() => compressFile(fileData)}
                      size="sm"
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      Compress
                    </Button>
                  )}

                  {isCompressed && (
                    <Button
                      onClick={() => handleDownload(fileData)}
                      size="sm"
                      className="bg-green-600 hover:bg-green-700 text-white"
                      disabled={isInCountdown}
                    >
                      {isInCountdown ? (
                        <div className="flex items-center gap-2">
                          <Clock size={16} />
                          Download in {delayCountdowns[id]}s
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Download size={16} />
                          Download
                        </div>
                      )}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

export default ImageCompressor

