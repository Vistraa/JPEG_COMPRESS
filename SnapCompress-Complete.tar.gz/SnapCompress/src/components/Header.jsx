import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'

const Header = () => {
  return (
    <header className="sticky top-0 z-50 bg-white/10 backdrop-blur-md border-b border-white/20">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-white">
          SnapCompress
        </Link>
        
        <Link to="/upgrade">
          <Button className="bg-white text-purple-600 hover:bg-gray-100 font-semibold">
            Upgrade to Pro
          </Button>
        </Link>
      </div>
    </header>
  )
}

export default Header

