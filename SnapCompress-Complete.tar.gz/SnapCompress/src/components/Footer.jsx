import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className="bg-white/10 backdrop-blur-md border-t border-white/20 mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="text-white/80 text-sm mb-4 md:mb-0">
            © 2024 SnapCompress. All rights reserved.
          </div>
          
          <div className="flex space-x-6">
            <Link 
              to="/terms" 
              className="text-white/80 hover:text-white text-sm transition-colors"
            >
              Terms of Service
            </Link>
            <Link 
              to="/privacy" 
              className="text-white/80 hover:text-white text-sm transition-colors"
            >
              Privacy Policy
            </Link>
            <Link 
              to="/contact" 
              className="text-white/80 hover:text-white text-sm transition-colors"
            >
              Contact
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

