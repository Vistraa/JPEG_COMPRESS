import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { Upload, FileImage, Rocket } from 'lucide-react'
import { Button } from '@/components/ui/button'
import ImageCompressor from '../components/ImageCompressor'

const HomePage = ({ 
  compressedCount, 
  setCompressedCount, 
  setShowUpgradeModal,
  hasDelayActive,
  setHasDelayActive 
}) => {
  const [files, setFiles] = useState([])
  const [error, setError] = useState('')

  const onDrop = useCallback((acceptedFiles, rejectedFiles) => {
    setError('')
    
    // Check if trying to upload more than 5 files total
    if (files.length + acceptedFiles.length > 5) {
      setError('You can compress up to 5 images at once.')
      return
    }

    // Validate file types
    const validFiles = acceptedFiles.filter(file => {
      return file.type === 'image/jpeg' || file.type === 'image/jpg'
    })

    if (validFiles.length !== acceptedFiles.length) {
      setError('Please upload only JPEG images.')
      return
    }

    // Add new files to existing files
    setFiles(prev => [...prev, ...validFiles.map(file => ({
      file,
      id: Math.random().toString(36).substr(2, 9),
      compressed: null,
      progress: 0,
      isCompressing: false,
      isCompressed: false
    }))])
  }, [files.length])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg']
    },
    multiple: true,
    maxFiles: 5
  })

  const removeFile = (id) => {
    setFiles(prev => prev.filter(file => file.id !== id))
  }

  const clearAll = () => {
    setFiles([])
    setError('')
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* AdSense Placeholder - Top Banner */}
      <div className="bg-white/10 backdrop-blur-md rounded-lg p-4 mb-8 text-center text-white/60">
        {/* AdSense Placeholder - Top Banner */}
        [Advertisement Space - Top Banner]
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Main Content */}
        <div className="flex-1">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
              Compress Your JPEGs – Free, Fast, Forever
            </h1>
            <p className="text-xl text-white/90 mb-8">
              Drag and drop to shrink your images without sacrificing quality
            </p>
          </div>

          {/* Upload Zone */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 mb-8">
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all ${
                isDragActive 
                  ? 'border-white bg-white/10' 
                  : 'border-white/50 hover:border-white hover:bg-white/5'
              }`}
            >
              <input {...getInputProps()} />
              <Upload className="mx-auto mb-4 text-white" size={48} />
              <h3 className="text-xl font-semibold text-white mb-2">
                {isDragActive ? 'Drop your JPEG images here' : 'Drag & drop JPEG images here'}
              </h3>
              <p className="text-white/70 mb-4">
                or click to browse files
              </p>
              <p className="text-sm text-white/60">
                Maximum 5 images • JPEG format only
              </p>
            </div>

            {error && (
              <div className="mt-4 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-100">
                {error}
              </div>
            )}

            {files.length > 0 && (
              <div className="mt-6">
                <div className="flex justify-between items-center mb-4">
                  <h4 className="text-lg font-semibold text-white">
                    Selected Images ({files.length}/5)
                  </h4>
                  <Button 
                    variant="outline" 
                    onClick={clearAll}
                    className="text-white border-white/50 hover:bg-white/10"
                  >
                    Clear All
                  </Button>
                </div>

                <ImageCompressor 
                  files={files}
                  setFiles={setFiles}
                  removeFile={removeFile}
                  compressedCount={compressedCount}
                  setCompressedCount={setCompressedCount}
                  setShowUpgradeModal={setShowUpgradeModal}
                  hasDelayActive={hasDelayActive}
                />
              </div>
            )}
          </div>

          {/* Trust Section */}
          <div className="text-center bg-white/10 backdrop-blur-md rounded-xl p-6">
            <div className="flex items-center justify-center gap-2 text-white">
              <Rocket className="text-yellow-300" size={24} />
              <span className="text-lg font-semibold">
                Over 12,000 images compressed this week!
              </span>
            </div>
          </div>
        </div>

        {/* AdSense Placeholder - Sidebar */}
        <div className="lg:w-80">
          <div className="sticky top-24 bg-white/10 backdrop-blur-md rounded-lg p-6 text-center text-white/60">
            {/* AdSense Placeholder - Sidebar */}
            <div className="mb-4">
              [Advertisement Space]
            </div>
            <div className="mb-4">
              [Sidebar Banner]
            </div>
            <div>
              [Sponsored Content]
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default HomePage

