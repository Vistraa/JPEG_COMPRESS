import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { useState } from 'react'
import './App.css'

// Components
import Header from './components/Header'
import Footer from './components/Footer'
import UpgradeModal from './components/UpgradeModal'

// Pages
import HomePage from './pages/HomePage'
import UpgradePage from './pages/UpgradePage'
import TermsPage from './pages/TermsPage'
import PrivacyPage from './pages/PrivacyPage'
import ContactPage from './pages/ContactPage'

function App() {
  const [showUpgradeModal, setShowUpgradeModal] = useState(false)
  const [compressedCount, setCompressedCount] = useState(0)
  const [hasDelayActive, setHasDelayActive] = useState(false)

  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-pink-500">
        <Header />
        
        <main className="flex-1">
          <Routes>
            <Route 
              path="/" 
              element={
                <HomePage 
                  compressedCount={compressedCount}
                  setCompressedCount={setCompressedCount}
                  setShowUpgradeModal={setShowUpgradeModal}
                  hasDelayActive={hasDelayActive}
                  setHasDelayActive={setHasDelayActive}
                />
              } 
            />
            <Route path="/upgrade" element={<UpgradePage />} />
            <Route path="/terms" element={<TermsPage />} />
            <Route path="/privacy" element={<PrivacyPage />} />
            <Route path="/contact" element={<ContactPage />} />
          </Routes>
        </main>

        <Footer />

        {showUpgradeModal && (
          <UpgradeModal 
            onClose={() => setShowUpgradeModal(false)}
            onMaybeLater={() => {
              setShowUpgradeModal(false)
              setHasDelayActive(true)
            }}
          />
        )}
      </div>
    </Router>
  )
}

export default App

