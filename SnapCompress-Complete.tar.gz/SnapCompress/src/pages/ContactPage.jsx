import { Mail, MessageCircle, Clock, MapPin } from 'lucide-react'

const ContactPage = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Contact Us
          </h1>
          <p className="text-xl text-white/90">
            We'd love to hear from you. Get in touch with our team.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Contact Information */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-white mb-6">Get in Touch</h2>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <Mail className="text-purple-300 mt-1" size={24} />
                <div>
                  <h3 className="text-lg font-semibold text-white mb-1">Email</h3>
                  <p className="text-white/80">support@snapcompress.com</p>
                  <p className="text-white/60 text-sm mt-1">
                    For general inquiries and support
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <MessageCircle className="text-blue-300 mt-1" size={24} />
                <div>
                  <h3 className="text-lg font-semibold text-white mb-1">Business Inquiries</h3>
                  <p className="text-white/80">business@snapcompress.com</p>
                  <p className="text-white/60 text-sm mt-1">
                    For partnerships and business opportunities
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Clock className="text-green-300 mt-1" size={24} />
                <div>
                  <h3 className="text-lg font-semibold text-white mb-1">Response Time</h3>
                  <p className="text-white/80">Within 24 hours</p>
                  <p className="text-white/60 text-sm mt-1">
                    We typically respond to all inquiries within one business day
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <MapPin className="text-pink-300 mt-1" size={24} />
                <div>
                  <h3 className="text-lg font-semibold text-white mb-1">Location</h3>
                  <p className="text-white/80">San Francisco, CA</p>
                  <p className="text-white/60 text-sm mt-1">
                    Serving users worldwide
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* FAQ Section */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-white mb-6">Common Questions</h2>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  How do I report a bug?
                </h3>
                <p className="text-white/80 text-sm">
                  Send us an email at support@snapcompress.com with details about the issue, 
                  including your browser type and steps to reproduce the problem.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  Can I request new features?
                </h3>
                <p className="text-white/80 text-sm">
                  Absolutely! We love hearing feature requests from our users. 
                  Email us your ideas and we'll consider them for future updates.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  How do I cancel my Pro subscription?
                </h3>
                <p className="text-white/80 text-sm">
                  You can cancel your subscription at any time by emailing us at 
                  support@snapcompress.com. No questions asked, no cancellation fees.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  Is my data secure?
                </h3>
                <p className="text-white/80 text-sm">
                  Yes! All image compression happens locally in your browser. 
                  Your images never leave your device, ensuring complete privacy and security.
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  Do you offer enterprise solutions?
                </h3>
                <p className="text-white/80 text-sm">
                  Yes, we offer custom enterprise solutions for businesses with high-volume 
                  compression needs. Contact us at business@snapcompress.com for more information.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Additional Contact Methods */}
        <div className="mt-12 text-center bg-white/10 backdrop-blur-md rounded-2xl p-8">
          <h2 className="text-2xl font-bold text-white mb-4">
            Other Ways to Reach Us
          </h2>
          <p className="text-white/80 mb-6">
            We're active on social media and love connecting with our community
          </p>
          
          <div className="flex justify-center gap-6 text-white/60">
            <span>Twitter: @SnapCompress</span>
            <span>•</span>
            <span>LinkedIn: SnapCompress</span>
            <span>•</span>
            <span>GitHub: snapcompress</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ContactPage

