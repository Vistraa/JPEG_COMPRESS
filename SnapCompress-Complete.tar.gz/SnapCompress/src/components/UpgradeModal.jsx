import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { X } from 'lucide-react'

const UpgradeModal = ({ onClose, onMaybeLater }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl p-8 max-w-md mx-4 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X size={24} />
        </button>
        
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Want to compress UNLIMITED images instantly?
          </h2>
          
          <p className="text-gray-600 mb-6">
            Get lightning-fast compression, bulk upload, and priority support. No ads, no delays.
          </p>
          
          <div className="space-y-3">
            <Link to="/upgrade" className="block">
              <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3">
                Upgrade Now
              </Button>
            </Link>
            
            <Button
              variant="outline"
              onClick={onMaybeLater}
              className="w-full border-gray-300 text-gray-700 hover:bg-gray-50 font-semibold py-3"
            >
              Maybe Later
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default UpgradeModal

