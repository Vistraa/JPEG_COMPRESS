const PrivacyPage = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 md:p-12">
          <h1 className="text-4xl font-bold text-white mb-8 text-center">
            Privacy Policy
          </h1>
          
          <div className="text-white/90 space-y-6 leading-relaxed">
            <p className="text-sm text-white/70 mb-8">
              Last updated: January 1, 2024
            </p>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">1. Information We Collect</h2>
              <p>
                SnapCompress is designed with privacy in mind. We collect minimal information to provide our service:
              </p>
              <ul className="list-disc list-inside mt-3 space-y-1 ml-4">
                <li>Usage analytics (page views, feature usage) through Google Analytics</li>
                <li>Technical information (browser type, device type) for optimization</li>
                <li>Account information for Pro subscribers (email, payment details)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">2. Image Processing</h2>
              <p>
                Your images are processed entirely in your browser using client-side JavaScript. 
                We do not upload, store, transmit, or have access to your images at any time. 
                All compression happens locally on your device, ensuring complete privacy.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">3. Cookies and Local Storage</h2>
              <p>
                We use cookies and local storage to:
              </p>
              <ul className="list-disc list-inside mt-3 space-y-1 ml-4">
                <li>Remember your preferences and settings</li>
                <li>Track usage for analytics purposes</li>
                <li>Manage your Pro subscription status</li>
                <li>Provide personalized advertising through Google AdSense</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">4. Third-Party Services</h2>
              <p>
                We use the following third-party services that may collect information:
              </p>
              <ul className="list-disc list-inside mt-3 space-y-1 ml-4">
                <li><strong>Google Analytics:</strong> For website usage analytics</li>
                <li><strong>Google AdSense:</strong> For displaying relevant advertisements</li>
                <li><strong>Payment Processors:</strong> For handling Pro subscription payments</li>
              </ul>
              <p className="mt-3">
                These services have their own privacy policies governing the collection and use of information.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">5. Advertising</h2>
              <p>
                We display advertisements through Google AdSense. These ads may be personalized based on your 
                browsing behavior across websites. You can opt out of personalized advertising by visiting 
                Google's Ad Settings or using browser extensions that block tracking.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">6. Data Security</h2>
              <p>
                We implement appropriate security measures to protect your personal information. 
                Since image processing happens locally in your browser, your images never leave your device, 
                providing the highest level of security for your content.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">7. Data Retention</h2>
              <p>
                We retain personal information only as long as necessary to provide our services. 
                Analytics data is retained according to Google Analytics' data retention policies. 
                Pro subscription data is retained for billing and legal compliance purposes.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">8. Your Rights</h2>
              <p>
                You have the right to:
              </p>
              <ul className="list-disc list-inside mt-3 space-y-1 ml-4">
                <li>Access the personal information we have about you</li>
                <li>Request correction of inaccurate information</li>
                <li>Request deletion of your personal information</li>
                <li>Opt out of marketing communications</li>
                <li>Disable cookies in your browser settings</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">9. Children's Privacy</h2>
              <p>
                Our service is not intended for children under 13 years of age. 
                We do not knowingly collect personal information from children under 13.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">10. Changes to Privacy Policy</h2>
              <p>
                We may update this privacy policy from time to time. We will notify you of any changes 
                by posting the new privacy policy on this page and updating the "Last updated" date.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">11. Contact Us</h2>
              <p>
                If you have any questions about this Privacy Policy, please contact us at privacy@snapcompress.com.
              </p>
            </section>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PrivacyPage

