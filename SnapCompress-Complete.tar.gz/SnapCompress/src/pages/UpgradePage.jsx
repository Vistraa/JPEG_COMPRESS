import { Button } from '@/components/ui/button'
import { Check, Zap, Upload, Shield, Clock } from 'lucide-react'

const UpgradePage = () => {
  const features = [
    {
      icon: <Zap className="text-yellow-400" size={24} />,
      title: "Unlimited Compression",
      description: "Compress as many images as you want, no daily limits"
    },
    {
      icon: <Upload className="text-blue-400" size={24} />,
      title: "Bulk Uploads",
      description: "Upload and compress up to 50 images at once"
    },
    {
      icon: <Shield className="text-green-400" size={24} />,
      title: "No Ads",
      description: "Clean, distraction-free interface without advertisements"
    },
    {
      icon: <Clock className="text-purple-400" size={24} />,
      title: "Fast Processing",
      description: "Priority servers for lightning-fast compression speeds"
    }
  ]

  const handleSubscribe = () => {
    // Placeholder for subscription logic
    alert('Subscription feature coming soon!')
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Upgrade to SnapCompress Pro
          </h1>
          <p className="text-xl text-white/90 mb-8">
            Unlock unlimited compression power and premium features
          </p>
        </div>

        {/* Pricing Card */}
        <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 md:p-12 mb-12 text-center">
          <div className="mb-8">
            <div className="text-5xl md:text-7xl font-bold text-white mb-2">
              $10
              <span className="text-2xl md:text-3xl text-white/70">/month</span>
            </div>
            <p className="text-white/80 text-lg">
              Cancel anytime • No hidden fees
            </p>
          </div>

          <Button 
            onClick={handleSubscribe}
            className="bg-white text-purple-600 hover:bg-gray-100 font-bold text-lg px-12 py-4 rounded-xl mb-8"
          >
            Subscribe Now
          </Button>

          <p className="text-white/60 text-sm">
            30-day money-back guarantee
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20"
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  {feature.icon}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-white/80">
                    {feature.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Comparison Table */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl overflow-hidden">
          <div className="p-6 border-b border-white/20">
            <h2 className="text-2xl font-bold text-white text-center">
              Free vs Pro Comparison
            </h2>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="text-white/80 font-semibold">Feature</div>
              <div className="text-white/80 font-semibold">Free</div>
              <div className="text-white font-semibold">Pro</div>
              
              <div className="text-white/90 py-3 border-t border-white/10">Images per session</div>
              <div className="text-white/70 py-3 border-t border-white/10">5</div>
              <div className="text-white py-3 border-t border-white/10">Unlimited</div>
              
              <div className="text-white/90 py-3 border-t border-white/10">Bulk upload</div>
              <div className="text-white/70 py-3 border-t border-white/10">✗</div>
              <div className="text-white py-3 border-t border-white/10">
                <Check className="mx-auto text-green-400" size={20} />
              </div>
              
              <div className="text-white/90 py-3 border-t border-white/10">Advertisements</div>
              <div className="text-white/70 py-3 border-t border-white/10">Yes</div>
              <div className="text-white py-3 border-t border-white/10">None</div>
              
              <div className="text-white/90 py-3 border-t border-white/10">Download delays</div>
              <div className="text-white/70 py-3 border-t border-white/10">20 seconds</div>
              <div className="text-white py-3 border-t border-white/10">Instant</div>
              
              <div className="text-white/90 py-3 border-t border-white/10">Priority support</div>
              <div className="text-white/70 py-3 border-t border-white/10">✗</div>
              <div className="text-white py-3 border-t border-white/10">
                <Check className="mx-auto text-green-400" size={20} />
              </div>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-16 text-center">
          <h2 className="text-3xl font-bold text-white mb-8">
            Frequently Asked Questions
          </h2>
          
          <div className="grid md:grid-cols-2 gap-8 text-left">
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-2">
                Can I cancel anytime?
              </h3>
              <p className="text-white/80">
                Yes, you can cancel your subscription at any time. No questions asked.
              </p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-2">
                Is my data secure?
              </h3>
              <p className="text-white/80">
                All compression happens in your browser. Your images never leave your device.
              </p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-2">
                What payment methods do you accept?
              </h3>
              <p className="text-white/80">
                We accept all major credit cards and PayPal for your convenience.
              </p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-md rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-2">
                Do you offer refunds?
              </h3>
              <p className="text-white/80">
                Yes, we offer a 30-day money-back guarantee if you're not satisfied.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default UpgradePage

